//
//  MJPerson.m
//  Interview01-block的copy
//
//  Created by MJ Lee on 2018/5/12.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import "MJPerson.h"

@implementation MJPerson

- (void)dealloc
{
    //[super dealloc];
    NSLog(@"MJPerson - dealloc");
}

@end
