//
//  main.m
//  Interview04-__block
//
//  Created by MJ Lee on 2018/5/12.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void (^MJBlock)(void);

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        
        __block int age = 10;
        MJBlock block = ^{
            age = 30;
            NSLog(@"age is %d", age);
        };
        
        block();
    }
    return 0;
}




